# EduTech

Plataforma educacional interativa com funcionalidades reais de autenticação, quizzes e criação de aulas, desenvolvida em React e Node.js para fins acadêmicos.

## Como rodar

### Backend
```
cd backend
npm install
node server.js
```

### Frontend
```
cd frontend
npm install
npm run dev
```

Acesse via navegador: http://localhost:5173

## Login de Teste
Aluno: aluno@edu / 1234
Professor: prof@edu / admin